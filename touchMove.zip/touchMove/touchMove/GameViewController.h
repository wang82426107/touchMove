//
//  GameViewController.h
//  touchMove
//

//  Copyright (c) 2016年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>

@interface GameViewController : UIViewController

@end
