//
//  GameScene.m
//  touchMove
//
//  Created by songjc on 16/8/18.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "GameScene.h"

@implementation GameScene

-(instancetype)initWithSize:(CGSize)size{

    if (self = [super initWithSize:size]) {
        
        self.backgroundColor = [SKColor whiteColor];
        
    }

    return self;

}

-(void)didMoveToView:(SKView *)view{

    [super didMoveToView:view];

    [self backgroundNode];
    
    [self planeNode];
    
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panAction:)];
    
    [self.view addGestureRecognizer:pan];
    
}

#pragma mark ----创建背景----

-(void)backgroundNode{

    SKSpriteNode *backgroundNode = [SKSpriteNode spriteNodeWithImageNamed:@"bg_02.jpg"];

    backgroundNode.position = CGPointZero;
    
    backgroundNode.zPosition = 0;
    
    backgroundNode.anchorPoint = CGPointZero;
    
    backgroundNode.size = self.size;
    
    [self addChild:backgroundNode];
    
}

#pragma mark ---- 创建飞船 ----

-(void)planeNode{

    SKSpriteNode *planeNode = [SKSpriteNode spriteNodeWithImageNamed:@"飞机.png"];
    
    planeNode.position = CGPointMake(self.size.width/2, self.size.height/2);
    
    planeNode.anchorPoint = CGPointMake(0.5, 0.5);
    
    planeNode.zPosition = 1;
    
    planeNode.name = @"plane";
    
    [self addChild:planeNode];

}

#pragma mark ---- 移动飞船 ----

BOOL isPlane ;

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    isPlane = NO;

    UITouch *touch = [touches anyObject];
    
    CGPoint  position = [touch locationInNode:self];
    
    SKNode *node = [self nodeAtPoint:position];
    
    if ([node.name isEqualToString:@"plane"]) {
        
        isPlane = YES;
        
    }

}



-(void)panAction:(UIPanGestureRecognizer *)sender{

    if (isPlane ) {
        SKSpriteNode *plane = (SKSpriteNode *)[self childNodeWithName:@"plane"];
        
        CGPoint position = [sender locationInView:sender.view];
        
        position = CGPointMake(position.x, self.size.height -position.y);//因为坐标系不同,所以我们要进行转换..
        
        plane.position = position;

    }
}





@end
