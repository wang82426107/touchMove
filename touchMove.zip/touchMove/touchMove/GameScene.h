//
//  GameScene.h
//  touchMove
//
//  Created by songjc on 16/8/18.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene : SKScene

@end
